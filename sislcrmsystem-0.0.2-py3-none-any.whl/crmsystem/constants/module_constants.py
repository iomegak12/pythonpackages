class Constants(object):
    CUSTOMER_SERVICE_URL = ""
    MONGO_SERVER = ""
    MONGO_PORT = ""
    MONGO_DB = ""
    FLASK_DEBUG = ""


constants = Constants()

constants.CUSTOMER_SERVICE_URL = "CUSTOMER_SERVICE_URL"
constants.MONGO_SERVER = "MONGO_SERVER"
constants.MONGO_PORT = "MONGO_PORT"
constants.MONGO_DB = "MONGO_DB"
constants.FLASK_DEBUG = "FLASK_DEBUG"
