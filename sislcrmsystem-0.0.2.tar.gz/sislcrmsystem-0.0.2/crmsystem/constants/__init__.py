from .module_constants import constants as GlobalConstants
